<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Mediator extends Theme
{

}

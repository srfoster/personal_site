# v1.2.0
## 01/06/2016

1. [](#improved)
    * Dropped an extraneous debug statement
1. [](#bugfix)
	* Fixed RSS link
	* Fix tag links on a root domain site

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.3
## 03/01/2015

1. [](#improved)
    * Switched to Grav's built-in `jQuery` assets

# v1.0.2
## 02/19/2015

2. [](#improved)
	* Updated README
	* Fixed feed URL on homepage
	* Added demo link
    * Implemented new `param_sep` variable from Grav 0.9.18

# v1.0.1
## 02/10/2015

1. [](#new)
    * ChangeLog started...

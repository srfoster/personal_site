---
title:  "Welcome to Grav"
slug: welcome-to-grav
date:   11/30/2014
taxonomy:
    tag: [theme, grav, installation]
image: swim.jpg
---
#Mediator Formats and CSS features

Examples for different formats and css features

#Header Formats
#Header1
##Header2

#Blockquotes
>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus

#Lists
##orderd lists
1. one
2. two
3. three

##unorderd lists
- Apple
- Banana
- Plum

#Links
This is an [example link](http://example.com/ "With a Title").

#Images
![Unsplash Image](stuff.jpg)

#Code
```
#container {
  float: left;
  margin: 0 -240px 0 0;
  width: 100%;
}
```

#Combinations
>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus
>
> - Apple
> - Banana
> - Plum

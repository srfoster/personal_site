---
title: "Sample Link Post"
slug: sample-link-post
description: "Example and code for using link posts."
date: 08/12/2014
taxonomy:
    tag: [sample post, link post]
comments: true
link: http://getgrav.org
---

This theme supports **link posts**, made famous by John Gruber. To use, just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done.
